/**
 * Pacote contendo as classes de negócio do sistema, ou seja,
 * as classes principais que importam para o negócio do cliente (dono do sistema).
 *
 * @author Manoel Campos da Silva Filho
 */
package com.sistemabancario.model;
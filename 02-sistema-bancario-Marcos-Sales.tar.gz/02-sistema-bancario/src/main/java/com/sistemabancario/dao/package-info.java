/**
 * Pacote contendo classes que implementam o Padrão de Projetos Data Access Objects (DAO).
 * Tais classes são responsáveis por fazer o acesso ao banco de dados.
 *
 * @author Manoel Campos da Silva Filho
 */
package com.sistemabancario.dao;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sistemabancario.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author Marcos
 */
    public class MovimentacaoTest {

    private Movimentacao movimentacao = new Movimentacao();

    @Before
    public void setUp() {

    }

    @Test
    public void testMovimentacaoNaoConfirmada() {

        assertFalse(movimentacao.isConfirmada());

    }

    
    @Test
    public void testValorPositivo() {
        final double invalido = 100;
        movimentacao.setValor(invalido);
        final double obtido = movimentacao.getValor();
        assertEquals(invalido, obtido, 0.0001);
    }
    
    
    @Test
    public void testValorNegativo() {
        final double invalido = -100;
        try {
            movimentacao.setValor(invalido);
        } catch (IllegalArgumentException e) {
        }
        final double obtido = movimentacao.getValor();
        assertNotEquals(invalido, obtido, 0.0001);
    }


    @Test
    public void testCreditoMaiusculo() {

        final char esperado = 'C';
        movimentacao.setTipo(esperado);
        final char obtido = movimentacao.getTipo();
        assertEquals(esperado, obtido);
        movimentacao.setConfirmada(true);
    }

    @Test
    public void testCreditoMinusculo() {
        final char esperado = 'c';
        movimentacao.setTipo(esperado);
        final char obtido = movimentacao.getTipo();
        assertEquals(esperado, obtido);

    }

    @Test
    public void testTipoInvalido() {
        final char invalido = 'X';
        try {
            movimentacao.setTipo(invalido);
        } catch (IllegalArgumentException e) {
        }
        final char obtido = movimentacao.getTipo();
        assertNotEquals(invalido, obtido);

    }

    @Test(expected = IllegalArgumentException.class)
    public void testTipoInvalidoExcecao() {
        final char invalido = 'X';
        movimentacao.setTipo(invalido);
    }

    public static void main(String[] args) {

        MovimentacaoTest classeTeste = new MovimentacaoTest();

        classeTeste.testCreditoMaiusculo();
        classeTeste.testMovimentacaoNaoConfirmada();
    }
    
    /*@Test
    public void test{
        
    }*/
}